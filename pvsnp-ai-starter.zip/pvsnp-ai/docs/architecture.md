# Architecture

Explorer -> Director -> Experiment Runner -> PySAT/Z3 -> Counterexample -> Research DB

Future:
Literature Agent -> novelty checks
Formalizer -> Lean 4 + Mathlib
Reviewer -> human research gate

Trust model:
LLM output < computational evidence < formal verification < human-reviewed publication.
