# PvsNP-AI

AI-assisted mathematical research laboratory for computational complexity.

## MVP
Generate restricted-SAT hypotheses, run reproducible experiments, search for counterexamples, and record research lineage.

**This project does not claim to solve P vs NP.** LLM output is untrusted until independently tested and, where practical, formally verified.

## Quick start
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -e ".[dev]"
pvsnp demo
pytest
```

SQLite is used in the MVP. PostgreSQL can be introduced later without changing the research model.
