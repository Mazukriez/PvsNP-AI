# Lean verification layer

Reserved for Lean 4 + Mathlib.

Future modules:
- PvsNP/Basic.lean
- PvsNP/Definitions.lean
- PvsNP/SAT.lean
- PvsNP/Reductions.lean
- PvsNP/Complexity.lean

The Python experiment layer must never treat an LLM-generated proof as verified.
