from pvsnp_ai.generator import random_3sat
from pvsnp_ai.sat_engine import solve

def test_sat_solver():
    result, model = solve(random_3sat(8, 16, 42))
    assert isinstance(result, bool)
    if result:
        assert model is not None
