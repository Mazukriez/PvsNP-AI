from pvsnp_ai.db import ResearchDB
from pvsnp_ai.models import Hypothesis

def test_database(tmp_path):
    db = ResearchDB(str(tmp_path / "test.db"))
    db.add_hypothesis(Hypothesis("H-X", "Test", "A test claim"))
