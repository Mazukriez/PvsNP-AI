from .models import Hypothesis

class ExplorerAgent:
    def generate(self):
        return [
            Hypothesis(
                "H-00001",
                "Clause-signature heuristic",
                "A simple clause-signature heuristic can always decide arbitrary 3-SAT.",
                metadata={"trusted": False}),
            Hypothesis(
                "H-00002",
                "Bounded local consistency",
                "For a restricted family of low-width formulas, local consistency may determine satisfiability.",
                metadata={"trusted": False})
        ]

class SkepticAgent:
    def critique(self, hypothesis):
        return [
            "Test larger instances.",
            "Generate adversarial formulas.",
            "Check definitions and hidden assumptions.",
            "Compare against known complexity results."
        ]

class DirectorAgent:
    def select(self, hypotheses):
        return hypotheses[0]
