from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timezone
from typing import Any

class Status(str, Enum):
    NEW = "NEW"
    TESTING = "TESTING"
    FAILED = "FAILED"
    PROMISING = "PROMISING"
    FORMALIZING = "FORMALIZING"
    VERIFIED = "VERIFIED"

@dataclass
class Hypothesis:
    id: str
    title: str
    claim: str
    domain: str = "restricted-3SAT"
    status: Status = Status.NEW
    parent_id: str | None = None
    score: float = 0.0
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class ExperimentResult:
    hypothesis_id: str
    total: int
    passed: int
    failed: int
    counterexamples: list[dict[str, Any]]
    runtime_seconds: float
