import random
from .sat_engine import SATInstance

def random_3sat(num_vars, num_clauses, seed):
    rng = random.Random(seed)
    clauses = []
    for _ in range(num_clauses):
        vars_ = rng.sample(range(1, num_vars + 1), 3)
        clauses.append([v if rng.random() < 0.5 else -v for v in vars_])
    return SATInstance(clauses, num_vars)
