import argparse
from .agents import ExplorerAgent, DirectorAgent, SkepticAgent
from .db import ResearchDB
from .experiment import run_baseline
from .models import Status

def demo():
    db = ResearchDB()
    hs = ExplorerAgent().generate()
    for h in hs:
        db.add_hypothesis(h)
    chosen = DirectorAgent().select(hs)
    print(f"Selected: {chosen.id} - {chosen.title}")
    for item in SkepticAgent().critique(chosen):
        print(f"Skeptic: {item}")
    db.update_status(chosen.id, Status.TESTING)
    result = run_baseline(chosen.id)
    db.add_experiment(result)
    status = Status.FAILED if result.failed else Status.PROMISING
    db.update_status(chosen.id, status)
    print(f"Trials={result.total} Passed={result.passed} Failed={result.failed}")
    print(f"Status={status.value}")
    if result.counterexamples:
        print("First counterexample:", result.counterexamples[0])

def main():
    parser = argparse.ArgumentParser(prog="pvsnp")
    parser.add_argument("command", choices=["demo"])
    args = parser.parse_args()
    if args.command == "demo":
        demo()

if __name__ == "__main__":
    main()
