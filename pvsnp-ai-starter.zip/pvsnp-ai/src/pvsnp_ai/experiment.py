import time
from .generator import random_3sat
from .sat_engine import solve
from .models import ExperimentResult

def run_baseline(hypothesis_id, trials=50, seed=1000):
    start = time.perf_counter()
    passed = 0
    failures = []
    for i in range(trials):
        instance = random_3sat(12, 30, seed + i)
        truth, _ = solve(instance)
        # Intentionally weak candidate used only to demonstrate falsification.
        candidate = truth if i % 7 != 0 else False
        if candidate == truth:
            passed += 1
        else:
            failures.append({
                "trial": i, "seed": seed+i,
                "expected": truth, "candidate": candidate,
                "clauses": instance.clauses
            })
    return ExperimentResult(
        hypothesis_id, trials, passed, trials-passed, failures,
        time.perf_counter()-start)
