import json
import sqlite3
from pathlib import Path
from .models import Hypothesis, Status, ExperimentResult

class ResearchDB:
    def __init__(self, path="pvsnp_ai.db"):
        self.path = Path(path)
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript("""
        CREATE TABLE IF NOT EXISTS hypotheses (
          id TEXT PRIMARY KEY, title TEXT, claim TEXT, domain TEXT,
          status TEXT, parent_id TEXT, score REAL, created_at TEXT, metadata TEXT
        );
        CREATE TABLE IF NOT EXISTS experiments (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          hypothesis_id TEXT, total INTEGER, passed INTEGER, failed INTEGER,
          runtime_seconds REAL, counterexamples TEXT
        );
        """)
        self.conn.commit()

    def add_hypothesis(self, h: Hypothesis):
        self.conn.execute(
            "INSERT OR REPLACE INTO hypotheses VALUES (?,?,?,?,?,?,?,?,?)",
            (h.id, h.title, h.claim, h.domain, h.status.value, h.parent_id,
             h.score, h.created_at, json.dumps(h.metadata)))
        self.conn.commit()

    def update_status(self, hypothesis_id, status):
        self.conn.execute("UPDATE hypotheses SET status=? WHERE id=?",
                          (status.value, hypothesis_id))
        self.conn.commit()

    def add_experiment(self, r: ExperimentResult):
        self.conn.execute(
            "INSERT INTO experiments(hypothesis_id,total,passed,failed,runtime_seconds,counterexamples) VALUES (?,?,?,?,?,?)",
            (r.hypothesis_id, r.total, r.passed, r.failed,
             r.runtime_seconds, json.dumps(r.counterexamples)))
        self.conn.commit()
