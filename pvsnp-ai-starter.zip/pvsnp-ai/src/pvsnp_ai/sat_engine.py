from dataclasses import dataclass
from pysat.solvers import Solver

@dataclass
class SATInstance:
    clauses: list[list[int]]
    num_vars: int

def solve(instance):
    with Solver(name="glucose3") as solver:
        for clause in instance.clauses:
            solver.add_clause(clause)
        ok = solver.solve()
        return ok, solver.get_model() if ok else None
